import React from "react";

export default function RayTopDetails() {
  return (
    <div className="bg-white text-gray-900 font-sans">
      <section className="text-center py-12 px-4 bg-gray-100">
        <h1 className="text-4xl font-bold mb-4">RayTopDetails</h1>
        <p className="text-xl mb-6">Premium Mobile Detailing at Your Doorstep</p>
        <button className="bg-blue-600 text-white px-6 py-2 rounded text-lg">Book Now</button>
      </section>

      <section className="py-12 px-6">
        <h2 className="text-3xl font-semibold mb-6 text-center">Our Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[
            { title: "Basic Exterior", price: "$55", desc: "Exterior wash and shine." },
            { title: "Interior Package", price: "$100", desc: "Vacuum, wipe down, shampoo seats & floors." },
            { title: "Basic Package", price: "$149", desc: "Exterior + interior cleaning." },
            { title: "Deluxe Package", price: "$199", desc: "Full detail with clay, wax, and deep shampoo." },
          ].map(({ title, price, desc }) => (
            <div key={title} className="p-6 border rounded shadow">
              <h3 className="text-xl font-bold mb-2">{title}</h3>
              <p className="mb-1">{desc}</p>
              <p className="font-semibold">{price}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-12 px-6 bg-gray-50">
        <h2 className="text-3xl font-semibold mb-6 text-center">Photo Gallery</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="bg-gray-200 h-40 rounded-lg"></div>
          ))}
        </div>
      </section>

      <section className="py-12 px-6">
        <h2 className="text-3xl font-semibold mb-6 text-center">What Our Clients Say</h2>
        <div className="space-y-4 max-w-2xl mx-auto">
          <div className="p-4 border rounded shadow">“RayTopDetails made my car look brand new again!” – Alex R.</div>
          <div className="p-4 border rounded shadow">“Fast, friendly, and professional. Highly recommend.” – Jamie P.</div>
        </div>
      </section>

      <section className="py-12 px-6 bg-gray-100">
        <h2 className="text-3xl font-semibold mb-6 text-center">Book or Contact Us</h2>
        <form className="max-w-xl mx-auto grid gap-4">
          <input type="text" placeholder="Name" className="p-3 border rounded" required />
          <input type="email" placeholder="Email" className="p-3 border rounded" required />
          <input type="tel" placeholder="Phone" className="p-3 border rounded" required />
          <select className="p-3 border rounded">
            <option>Choose Service</option>
            <option>Basic Exterior</option>
            <option>Interior Package</option>
            <option>Basic Package</option>
            <option>Deluxe Package</option>
          </select>
          <input type="date" className="p-3 border rounded" />
          <textarea placeholder="Additional Notes" className="p-3 border rounded" rows={4}></textarea>
          <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded">Submit</button>
        </form>
      </section>

      <footer className="text-center text-sm text-gray-600 py-6">
        <p>&copy; {new Date().getFullYear()} RayTopDetails. All rights reserved.</p>
        <div className="mt-2">Phone | Email | Instagram</div>
      </footer>
    </div>
  );
}